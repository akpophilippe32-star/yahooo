import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../models/recipe_model.dart';
import '../../repositories/recipe_repository.dart';
import '../auth/data/auth_repository.dart';

import '../../models/category_model.dart';
import '../../repositories/category_repository.dart';

import 'widgets/home_header.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final RecipeRepository _recipeRepository = RecipeRepository();
  final AuthRepository _authRepository = AuthRepository();
  final CategoryRepository _categoryRepository = CategoryRepository();

  late Future<List<CategoryModel>> _categoriesFuture;
  late Future<List<RecipeModel>> _recipesFuture;

  String? _userRole;
  bool _isLoadingRole = true;

  Future<void> _loadUserRole() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user == null) {
      if (!mounted) return;

      setState(() {
        _userRole = null;
        _isLoadingRole = false;
      });

      return;
    }

    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();

      if (!mounted) return;

      setState(() {
        _userRole = profile['role'] as String?;
        _isLoadingRole = false;
      });
    } catch (error) {
      debugPrint('Erreur récupération rôle : $error');

      if (!mounted) return;

      setState(() {
        _userRole = null;
        _isLoadingRole = false;
      });
    }
  }



  @override
  @override
  void initState() {
    super.initState();

    _categoriesFuture = _categoryRepository.getCategories();
    _recipesFuture = _recipeRepository.getPublishedRecipes();

    _loadUserRole();
  }
  Future<void> _refresh() async {
    setState(() {
      _categoriesFuture = _categoryRepository.getCategories();
      _recipesFuture = _recipeRepository.getPublishedRecipes();
    });

    await Future.wait([
      _categoriesFuture,
      _recipesFuture,
    ]);
  }
  Future<void> _logout() async {
    await _authRepository.signOut();

    if (!mounted) return;

    Navigator.of(context).pushReplacementNamed('/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Pour l'instant, pas d'AppBar.
      // HomeHeader devient notre véritable en-tête Mealora.
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              16,
              16,
              16,
              32,
            ),
            children: [
              // =========================
              // HEADER MEALORA
              // =========================

              const HomeHeader(),

              const SizedBox(height: 28),

              if (!_isLoadingRole &&
                (_userRole == 'creator' || _userRole == 'admin'))
              Padding(
                padding: const EdgeInsets.only(bottom: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    FilledButton.icon(
                      onPressed: () {
                        Navigator.of(context).pushNamed('/create-recipe');
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Créer une recette'),
                    ),

                    const SizedBox(height: 12),

                    OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(context).pushNamed('/my-recipes');
                      },
                      icon: const Icon(Icons.restaurant_menu),
                      label: const Text('Mes recettes'),
                    ),
                  ],
                ),
              ),

              // =========================
              // CATÉGORIES
              // =========================

              const Text(
                'Catégories',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              FutureBuilder<List<CategoryModel>>(
                future: _categoriesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState ==
                      ConnectionState.waiting) {
                    return const SizedBox(
                      height: 50,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Text(
                      'Erreur catégories : ${snapshot.error}',
                    );
                  }

                  final categories = snapshot.data ?? [];

                  if (categories.isEmpty) {
                    return const Text(
                      'Aucune catégorie disponible.',
                    );
                  }

                  return SizedBox(
                    height: 45,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: categories.length,
                      separatorBuilder: (context, index) {
                        return const SizedBox(width: 10);
                      },
                      itemBuilder: (context, index) {
                        final category = categories[index];

                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: Theme.of(context)
                                .colorScheme
                                .primaryContainer,
                            borderRadius:
                                BorderRadius.circular(30),
                          ),
                          child: Center(
                            child: Text(
                              category.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),

              const SizedBox(height: 32),

              // =========================
              // RECETTES
              // =========================

              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Nos recettes',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  IconButton(
                    onPressed: _logout,
                    tooltip: 'Se déconnecter',
                    icon: const Icon(
                      Icons.logout,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              FutureBuilder<List<RecipeModel>>(
                future: _recipesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState ==
                      ConnectionState.waiting) {
                    return const Center(
                      child: Padding(
                        padding: EdgeInsets.all(30),
                        child: CircularProgressIndicator(),
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Column(
                      children: [
                        const Icon(
                          Icons.error_outline,
                          size: 50,
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Impossible de charger les recettes.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${snapshot.error}',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _refresh,
                          child: const Text('Réessayer'),
                        ),
                      ],
                    );
                  }

                  final recipes = snapshot.data ?? [];

                  if (recipes.isEmpty) {
                    return const Center(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text(
                          'Aucune recette disponible.',
                          style: TextStyle(
                            fontSize: 18,
                          ),
                        ),
                      ),
                    );
                  }

                  return Column(
                    children: recipes.map(
                      (recipe) {
                        return RecipeCard(
                          recipe: recipe,
                          recipeRepository:
                              _recipeRepository,
                        );
                      },
                    ).toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// ============================================================
// RECIPE CARD
// ============================================================

class RecipeCard extends StatelessWidget {
  final RecipeModel recipe;
  final RecipeRepository recipeRepository;

  const RecipeCard({
    super.key,
    required this.recipe,
    required this.recipeRepository,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: recipeRepository.getRecipeImageUrl(
        recipe.imageUrl,
      ),
      builder: (context, imageSnapshot) {
        final imageUrl = imageSnapshot.data;

        return Card(
          margin: const EdgeInsets.only(bottom: 20),
          clipBehavior: Clip.antiAlias,
          elevation: 3,
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              // IMAGE
              if (imageSnapshot.connectionState ==
                  ConnectionState.waiting)
                const SizedBox(
                  height: 220,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              else if (imageUrl != null)
                Image.network(
                  imageUrl,
                  width: double.infinity,
                  height: 220,
                  fit: BoxFit.cover,
                  errorBuilder:
                      (context, error, stackTrace) {
                    return const RecipeImagePlaceholder();
                  },
                )
              else
                const RecipeImagePlaceholder(),

              // INFORMATIONS
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    if (recipe.categoryName != null)
                      Text(
                        recipe.categoryName!.toUpperCase(),
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context)
                              .colorScheme
                              .primary,
                        ),
                      ),

                    const SizedBox(height: 6),

                    Text(
                      recipe.title,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 8),

                    if (recipe.description != null)
                      Text(
                        recipe.description!,
                        style: const TextStyle(
                          fontSize: 14,
                        ),
                      ),

                    const SizedBox(height: 14),

                    Row(
                      children: [
                        if (recipe.prepTime != null) ...[
                          const Icon(
                            Icons.timer_outlined,
                            size: 18,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '${recipe.prepTime! + (recipe.cookTime ?? 0)} min',
                          ),
                        ],

                        const SizedBox(width: 20),

                        if (recipe.difficulty != null) ...[
                          const Icon(
                            Icons.restaurant_outlined,
                            size: 18,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            recipe.difficulty!,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}


// ============================================================
// IMAGE PLACEHOLDER
// ============================================================

class RecipeImagePlaceholder extends StatelessWidget {
  const RecipeImagePlaceholder({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 220,
      width: double.infinity,
      child: Center(
        child: Icon(
          Icons.restaurant,
          size: 70,
        ),
      ),
    );
  }
}