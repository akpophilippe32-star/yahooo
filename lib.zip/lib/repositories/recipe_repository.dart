import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/recipe_model.dart';

class RecipeRepository {
  final SupabaseClient _supabase = Supabase.instance.client;

  // ============================================================
  // RECETTES PUBLIÉES
  // ============================================================

  /// Récupère toutes les recettes publiées.
  Future<List<RecipeModel>> getPublishedRecipes() async {
    final response = await _supabase
        .from('recipes')
        .select('''
          id,
          title,
          description,
          image_url,
          prep_time,
          cook_time,
          servings,
          difficulty,
          diet_type,
          instructions,
          category_id,
          status,
          created_at,
          updated_at,
          published_at,
          categories (
            name
          )
        ''')
        .eq('status', 'published')
        .order('created_at', ascending: false);

    return (response as List).map((recipe) {
      final data = Map<String, dynamic>.from(recipe);

      final category = data['categories'];

      if (category is Map<String, dynamic>) {
        data['category_name'] = category['name'];
      } else {
        data['category_name'] = null;
      }

      data.remove('categories');

      return RecipeModel.fromMap(data);
    }).toList();
  }

  // ============================================================
  // MES RECETTES
  // ============================================================

  /// Récupère toutes les recettes créées par l'utilisateur connecté.
  Future<List<RecipeModel>> getMyRecipes() async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    final response = await _supabase
        .from('recipes')
        .select('''
          id,
          title,
          description,
          image_url,
          prep_time,
          cook_time,
          servings,
          difficulty,
          diet_type,
          instructions,
          category_id,
          status,
          created_at,
          updated_at,
          published_at,
          categories (
            name
          )
        ''')
        .eq('author_id', user.id)
        .order('created_at', ascending: false);

    return (response as List).map((recipe) {
      final data = Map<String, dynamic>.from(recipe);

      final category = data['categories'];

      if (category is Map<String, dynamic>) {
        data['category_name'] = category['name'];
      } else {
        data['category_name'] = null;
      }

      data.remove('categories');

      return RecipeModel.fromMap(data);
    }).toList();
  }

  // ============================================================
  // CATÉGORIES
  // ============================================================

  /// Récupère les catégories disponibles pour la modification
  /// d'une recette.
  Future<List<Map<String, dynamic>>> getCategoriesForEdit() async {
    final response = await _supabase
        .from('categories')
        .select('id, name')
        .order('name', ascending: true);

    return (response as List)
        .map(
          (category) => Map<String, dynamic>.from(category),
        )
        .toList();
  }

  // ============================================================
  // MODIFICATION D'UNE RECETTE
  // ============================================================

  /// Modifie les informations principales d'une recette.
  Future<void> updateRecipe({
    required int recipeId,
    required String title,
    String? description,
    int? categoryId,
    int? prepTime,
    int? cookTime,
    int? servings,
    String? difficulty,
    String? dietType,
    String? imageUrl,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    await _supabase
        .from('recipes')
        .update({
          'title': title,
          'description': description,
          'image_url': imageUrl,
          'category_id': categoryId,
          'prep_time': prepTime,
          'cook_time': cookTime,
          'servings': servings,
          'difficulty': difficulty,
          'diet_type': dietType,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', recipeId)
        .eq('author_id', user.id);
  }

  // ============================================================
  // DÉTAIL D'UNE RECETTE
  // ============================================================

  /// Récupère une recette avec ses informations principales,
  /// ses ingrédients et ses étapes.
  Future<Map<String, dynamic>> getRecipeDetails(
    int recipeId,
  ) async {
    // ============================================================
    // 1. RECETTE
    // ============================================================

    final recipeResponse = await _supabase
        .from('recipes')
        .select('''
          id,
          title,
          description,
          image_url,
          prep_time,
          cook_time,
          servings,
          difficulty,
          diet_type,
          instructions,
          category_id,
          status,
          created_at,
          updated_at,
          published_at,
          categories (
            name
          )
        ''')
        .eq('id', recipeId)
        .single();

    final recipeData =
        Map<String, dynamic>.from(recipeResponse);

    final category = recipeData['categories'];

    if (category is Map<String, dynamic>) {
      recipeData['category_name'] = category['name'];
    } else {
      recipeData['category_name'] = null;
    }

    recipeData.remove('categories');

    final recipe = RecipeModel.fromMap(recipeData);

    // ============================================================
    // 2. INGRÉDIENTS
    // ============================================================

    final ingredientsResponse = await _supabase
        .from('recipe_ingredients')
        .select('''
          id,
          recipe_id,
          ingredient_id,
          quantity,
          unit,
          optional,
          created_at,
          ingredients (
            id,
            name,
            description,
            image_url
          )
        ''')
        .eq('recipe_id', recipeId)
        .order('id', ascending: true);

    final ingredients =
        (ingredientsResponse as List).map((ingredient) {
      return Map<String, dynamic>.from(ingredient);
    }).toList();

    // ============================================================
    // 3. ÉTAPES
    // ============================================================

    final stepsResponse = await _supabase
        .from('recipe_steps')
        .select('''
          id,
          recipe_id,
          step_number,
          instruction,
          image_url,
          created_at
        ''')
        .eq('recipe_id', recipeId)
        .order('step_number', ascending: true);

    final steps =
        (stepsResponse as List).map((step) {
      return Map<String, dynamic>.from(step);
    }).toList();

    return {
      'recipe': recipe,
      'ingredients': ingredients,
      'steps': steps,
    };
  }

  // ============================================================
  // CRÉATION D'UNE RECETTE
  // ============================================================

  /// Crée une nouvelle recette en brouillon.
  ///
  /// La recette, les ingrédients et les étapes sont créés
  /// par la fonction PostgreSQL `create_recipe_draft`.
  Future<Map<String, dynamic>> createDraft({
    required String title,
    String? description,
    int? categoryId,
    String? imageUrl,
    int? prepTime,
    int? cookTime,
    int? servings,
    String? difficulty,
    String? dietType,
    List<Map<String, dynamic>> ingredients = const [],
    List<Map<String, dynamic>> steps = const [],
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté. Impossible de créer la recette.',
      );
    }

    final response = await _supabase.rpc(
      'create_recipe_draft',
      params: {
        'p_title': title,
        'p_description': description,
        'p_category_id': categoryId,
        'p_image_url': imageUrl,
        'p_prep_time': prepTime,
        'p_cook_time': cookTime,
        'p_servings': servings,
        'p_difficulty': difficulty,
        'p_diet_type': dietType,
        'p_ingredients': ingredients,
        'p_steps': steps,
      },
    );

    if (response == null) {
      throw Exception(
        'La création de la recette n’a retourné aucun résultat.',
      );
    }

    if (response is Map<String, dynamic>) {
      return response;
    }

    return Map<String, dynamic>.from(response as Map);
  }

  // ============================================================
  // INGRÉDIENTS D'UNE RECETTE
  // ============================================================

  /// Récupère les ingrédients associés à une recette.
  Future<List<Map<String, dynamic>>> getRecipeIngredients(
    int recipeId,
  ) async {
    final response = await _supabase
        .from('recipe_ingredients')
        .select('''
          id,
          recipe_id,
          ingredient_id,
          quantity,
          unit,
          optional,
          created_at,
          ingredients (
            id,
            name,
            description,
            image_url
          )
        ''')
        .eq('recipe_id', recipeId)
        .order('id', ascending: true);

    return (response as List)
        .map(
          (ingredient) => Map<String, dynamic>.from(ingredient),
        )
        .toList();
  }

  // ============================================================
  // TOUS LES INGRÉDIENTS DU CATALOGUE
  // ============================================================

  /// Récupère la liste de tous les ingrédients disponibles.
  Future<List<Map<String, dynamic>>> getIngredients() async {
    final response = await _supabase
        .from('ingredients')
        .select('''
          id,
          name,
          description,
          image_url
        ''')
        .order('name', ascending: true);

    return (response as List)
        .map(
          (ingredient) => Map<String, dynamic>.from(ingredient),
        )
        .toList();
  }

    // ============================================================
  // ÉTAPES DE LA RECETTE
  // ============================================================

  /// Récupère les étapes d'une recette.
  Future<List<Map<String, dynamic>>> getRecipeSteps(
    int recipeId,
  ) async {
    final response = await _supabase
        .from('recipe_steps')
        .select('''
          id,
          recipe_id,
          step_number,
          instruction,
          image_url,
          created_at
        ''')
        .eq('recipe_id', recipeId)
        .order('step_number', ascending: true);

    return (response as List)
        .map(
          (step) => Map<String, dynamic>.from(step),
        )
        .toList();
  }

  // ============================================================
  // AJOUTER UNE ÉTAPE
  // ============================================================

  Future<Map<String, dynamic>> addRecipeStep({
    required int recipeId,
    required String instruction,
    String? imageUrl,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception('Utilisateur non connecté.');
    }

    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour modifier cette recette.',
      );
    }

    final lastStepResponse = await _supabase
        .from('recipe_steps')
        .select('step_number')
        .eq('recipe_id', recipeId)
        .order('step_number', ascending: false)
        .limit(1)
        .maybeSingle();

    final int nextStepNumber =
        ((lastStepResponse?['step_number'] as int?) ?? 0) + 1;

    final response = await _supabase
        .from('recipe_steps')
        .insert({
          'recipe_id': recipeId,
          'step_number': nextStepNumber,
          'instruction': instruction,
          'image_url': imageUrl,
        })
        .select('''
          id,
          recipe_id,
          step_number,
          instruction,
          image_url,
          created_at
        ''')
        .single();

    return Map<String, dynamic>.from(response);
  }

  // ============================================================
  // RÉORGANISER LES ÉTAPES
  // ============================================================

  Future<void> reorderRecipeSteps({
    required int recipeId,
    required List<int> orderedStepIds,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception('Utilisateur non connecté.');
    }

    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour réorganiser cette recette.',
      );
    }

    final existingResponse = await _supabase
        .from('recipe_steps')
        .select('id')
        .eq('recipe_id', recipeId);

    final existingIds = (existingResponse as List)
        .map((row) => row['id'])
        .whereType<int>()
        .toSet();

    final requestedIds = orderedStepIds.toSet();

    if (existingIds.length != orderedStepIds.length ||
        requestedIds.length != orderedStepIds.length ||
        !existingIds.containsAll(requestedIds)) {
      throw Exception(
        'La liste des étapes à réorganiser est invalide.',
      );
    }

    for (var index = 0; index < orderedStepIds.length; index++) {
      await _supabase
          .from('recipe_steps')
          .update({
            'step_number': 1000000 + index,
          })
          .eq('id', orderedStepIds[index])
          .eq('recipe_id', recipeId);
    }

    for (var index = 0; index < orderedStepIds.length; index++) {
      await _supabase
          .from('recipe_steps')
          .update({
            'step_number': index + 1,
          })
          .eq('id', orderedStepIds[index])
          .eq('recipe_id', recipeId);
    }
  }

  // ============================================================
  // AJOUTER UN INGRÉDIENT À UNE RECETTE
  // ============================================================

  /// Ajoute un ingrédient existant du catalogue à une recette.
  Future<Map<String, dynamic>> addRecipeIngredient({
    required int recipeId,
    required int ingredientId,
    num? quantity,
    String? unit,
    bool optional = false,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // Vérification que la recette appartient bien
    // à l'utilisateur connecté.
    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour modifier cette recette.',
      );
    }

    final response = await _supabase
        .from('recipe_ingredients')
        .insert({
          'recipe_id': recipeId,
          'ingredient_id': ingredientId,
          'quantity': quantity,
          'unit': unit,
          'optional': optional,
        })
        .select('''
          id,
          recipe_id,
          ingredient_id,
          quantity,
          unit,
          optional,
          created_at,
          ingredients (
            id,
            name,
            description,
            image_url
          )
        ''')
        .single();

    return Map<String, dynamic>.from(response);
  }

  // ============================================================
  // MODIFIER UN INGRÉDIENT
  // ============================================================

  /// Modifie la quantité, l'unité ou le caractère facultatif
  /// d'un ingrédient déjà associé à une recette.
  Future<Map<String, dynamic>> updateRecipeIngredient({
    required int recipeIngredientId,
    num? quantity,
    String? unit,
    bool? optional,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // On récupère d'abord la ligne afin de vérifier
    // que la recette appartient bien au Creator connecté.
    final existing = await _supabase
        .from('recipe_ingredients')
        .select('''
          id,
          recipe_id
        ''')
        .eq('id', recipeIngredientId)
        .maybeSingle();

    if (existing == null) {
      throw Exception(
        'Ingrédient de recette introuvable.',
      );
    }

    final recipeId = existing['recipe_id'];

    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour modifier cet ingrédient.',
      );
    }

    final updateData = <String, dynamic>{};

    if (quantity != null) {
      updateData['quantity'] = quantity;
    }

    if (unit != null) {
      updateData['unit'] = unit;
    }

    if (optional != null) {
      updateData['optional'] = optional;
    }

    if (updateData.isEmpty) {
      throw Exception(
        'Aucune modification à enregistrer.',
      );
    }

    final response = await _supabase
        .from('recipe_ingredients')
        .update(updateData)
        .eq('id', recipeIngredientId)
        .select('''
          id,
          recipe_id,
          ingredient_id,
          quantity,
          unit,
          optional,
          created_at,
          ingredients (
            id,
            name,
            description,
            image_url
          )
        ''')
        .single();

    return Map<String, dynamic>.from(response);
  }

  // ============================================================
  // SUPPRIMER UN INGRÉDIENT
  // ============================================================

  /// Supprime un ingrédient d'une recette.
  Future<void> deleteRecipeIngredient(
    int recipeIngredientId,
  ) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // On récupère la recette associée.
    final existing = await _supabase
        .from('recipe_ingredients')
        .select('recipe_id')
        .eq('id', recipeIngredientId)
        .maybeSingle();

    if (existing == null) {
      throw Exception(
        'Ingrédient de recette introuvable.',
      );
    }

    final recipeId = existing['recipe_id'];

    // Vérification de propriété de la recette.
    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour supprimer cet ingrédient.',
      );
    }

    await _supabase
        .from('recipe_ingredients')
        .delete()
        .eq('id', recipeIngredientId);
  }

  // ============================================================
  // IMAGE D'UNE RECETTE
  // ============================================================

  /// Génère une URL temporaire pour une image stockée
  /// dans le bucket privé `recipe-images`.
  Future<String?> getRecipeImageUrl(
    String? imagePath,
  ) async {
    if (imagePath == null ||
        imagePath.trim().isEmpty) {
      return null;
    }

    try {
      final path = imagePath.trim();

      final signedUrl = await _supabase.storage
          .from('recipe-images')
          .createSignedUrl(
            path,
            60 * 60,
          );

      return signedUrl;
    } catch (error) {
      debugPrint(
        'Erreur image [$imagePath] : $error',
      );

      return null;
    }
  }

  // ============================================================
  // TÉLÉVERSER UNE IMAGE DE RECETTE
  // ============================================================

  Future<String> uploadRecipeImage({
    required int recipeId,
    required String filePath,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // Vérifier que la recette appartient bien
    // à l'utilisateur connecté.
    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour modifier cette recette.',
      );
    }

    // Chemin de stockage de l'image.
    final storagePath =
        '$user.id/recipes/$recipeId/${DateTime.now().millisecondsSinceEpoch}.jpg';

    final file = File(filePath);

    await _supabase.storage
        .from('recipe-images')
        .upload(
          storagePath,
          file,
          fileOptions: const FileOptions(
            contentType: 'image/jpeg',
            upsert: false,
          ),
        );

    return storagePath;
  }
    // ============================================================
  // ÉTAPES DE PRÉPARATION
  // ============================================================

  /// Récupère toutes les étapes d'une recette.
 
  /// Modifie une étape de préparation.
  Future<void> updateRecipeStep({
    required int stepId,
    required String instruction,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // Récupérer la recette associée à l'étape.
    final existing = await _supabase
        .from('recipe_steps')
        .select('recipe_id')
        .eq('id', stepId)
        .maybeSingle();

    if (existing == null) {
      throw Exception(
        'Étape introuvable.',
      );
    }

    final recipeId = existing['recipe_id'];

    // Vérifier que la recette appartient bien
    // à l'utilisateur connecté.
    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour modifier cette étape.',
      );
    }

    await _supabase
        .from('recipe_steps')
        .update({
          'instruction': instruction,
        })
        .eq('id', stepId);
  }

  /// Supprime une étape de préparation.
  Future<void> deleteRecipeStep(
    int stepId,
  ) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      throw Exception(
        'Utilisateur non connecté.',
      );
    }

    // Récupérer la recette associée à l'étape.
    final existing = await _supabase
        .from('recipe_steps')
        .select('recipe_id')
        .eq('id', stepId)
        .maybeSingle();

    if (existing == null) {
      throw Exception(
        'Étape introuvable.',
      );
    }

    final recipeId = existing['recipe_id'];

    // Vérifier que la recette appartient bien
    // à l'utilisateur connecté.
    final recipe = await _supabase
        .from('recipes')
        .select('id')
        .eq('id', recipeId)
        .eq('author_id', user.id)
        .maybeSingle();

    if (recipe == null) {
      throw Exception(
        'Tu n’as pas les droits pour supprimer cette étape.',
      );
    }

    await _supabase
        .from('recipe_steps')
        .delete()
        .eq('id', stepId);

    final remainingResponse = await _supabase
        .from('recipe_steps')
        .select('id')
        .eq('recipe_id', recipeId)
        .order('step_number', ascending: true);

    final remainingIds = (remainingResponse as List)
        .map((row) => row['id'])
        .whereType<int>()
        .toList();

    if (remainingIds.isNotEmpty) {
      await reorderRecipeSteps(
        recipeId: recipeId,
        orderedStepIds: remainingIds,
      );
    }
  }
   
}