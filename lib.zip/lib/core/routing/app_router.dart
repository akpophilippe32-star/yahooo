import 'package:flutter/material.dart';

import '../../features/auth/presentation/login_page.dart';
import '../../features/auth/presentation/register_page.dart';
import '../../features/home/home_page.dart';
import '../../features/auth/presentation/welcome_page.dart';
import '../../features/recipes/presentation/create_recipe_page.dart';
import '../../pages/creator/my_recipes_page.dart';
class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(
          builder: (_) => const WelcomePage(),
        );

      case '/login':
        return MaterialPageRoute(
          builder: (_) => const LoginPage(),
        );

      case '/register':
        return MaterialPageRoute(
          builder: (_) => const RegisterPage(),
        );

      case '/home':
        return MaterialPageRoute(
          builder: (_) => const HomePage(),
        );
        case '/create-recipe':
        return MaterialPageRoute(
          builder: (_) => const CreateRecipePage(),
        );
        case '/my-recipes':
        return MaterialPageRoute(
          builder: (_) => const MyRecipesPage(),
        );
      default:
        return MaterialPageRoute(
          builder: (_) => const WelcomePage(),
        );
    }
  }
}